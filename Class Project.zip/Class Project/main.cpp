#include <iostream>
#include "StockMarket.h"
#include "TradingBot.h"

int main() {
    StockMarket market;

    // Add initial stocks
    market.addStock("AAPL", 150.0);
    market.addStock("GOOG", 2800.0);
    market.addStock("TSLA", 800.0);

    // Set up trading bot with a conservative strategy
    ConservativeStrategy strategy;
    TradingBot bot(&strategy);
    market.attach(&bot);

    // Simulate market changes over 10 days
    for (int day = 1; day <= 10; ++day) {
        std::cout << "Day " << day << ":\n";
        market.simulatePriceFluctuations();
        bot.executeTrade(market);
    }

    // Display final portfolio
    bot.displayPortfolio();

    return 0;
}
