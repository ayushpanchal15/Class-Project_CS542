#include "GUI.h"
#include <QMessageBox>

GUI::GUI(StockMarket* market, TradingBot* bot)
    : market(market), bot(bot) {
    stockTable = new QTableWidget(0, 2);
    stockTable->setHorizontalHeaderLabels({"Stock", "Price"});

    QPushButton* simulateButton = new QPushButton("Simulate Market");
    QPushButton* portfolioButton = new QPushButton("Show Portfolio");

    connect(simulateButton, &QPushButton::clicked, this, &GUI::simulateMarket);
    connect(portfolioButton, &QPushButton::clicked, this, &GUI::displayPortfolio);

    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget(stockTable);
    layout->addWidget(simulateButton);
    layout->addWidget(portfolioButton);

    QWidget* container = new QWidget();
    container->setLayout(layout);
    setCentralWidget(container);

    updateMarketView();
}

void GUI::updateMarketView() {
    stockTable->setRowCount(0);
    const auto& stocks = market->getStocks();
    for (const auto& [name, price] : stocks) {
        int row = stockTable->rowCount();
        stockTable->insertRow(row);
        stockTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(name)));
        stockTable->setItem(row, 1, new QTableWidgetItem(QString::number(price)));
    }
}

void GUI::simulateMarket() {
    market->simulatePriceFluctuations();
    bot->executeTrade(*market);
    updateMarketView();
}

void GUI::displayPortfolio() {
    QString summary = "Portfolio:\n";
    for (const auto& [stock, quantity] : bot->portfolio) {
        summary += QString::fromStdString(stock) + ": " + QString::number(quantity) + " shares\n";
    }
    summary += "Balance: $" + QString::number(bot->bank->getBalance());
    QMessageBox::information(this, "Portfolio", summary);
}
