#include "TradingBot.h"
#include <iostream>

std::string ConservativeStrategy::chooseStock(const std::unordered_map<std::string, double>& stocks) {
    std::string bestStock;
    double minPrice = std::numeric_limits<double>::max();

    for (const auto& [stock, price] : stocks) {
        if (price < minPrice) {
            minPrice = price;
            bestStock = stock;
        }
    }
    return bestStock;
}

TradingBot::TradingBot(InvestmentStrategy* strategy)
    : strategy(strategy), bank(BankingSystem::getInstance(1000.0)) {}

void TradingBot::update(const std::string& stock, double price) {
    std::cout << "Stock " << stock << " updated to $" << price << "\n";
}

void TradingBot::executeTrade(const StockMarket& market) {
    const auto& stocks = market.getStocks();
    std::string choice = strategy->chooseStock(stocks);
    if (bank->withdraw(100)) {
        portfolio[choice]++;
        std::cout << "Bought 1 share of " << choice << "\n";
    }
}

void TradingBot::displayPortfolio() const {
    std::cout << "Portfolio:\n";
    for (const auto& [stock, quantity] : portfolio) {
        std::cout << stock << ": " << quantity << " shares\n";
    }
    std::cout << "Remaining Balance: $" << bank->getBalance() << "\n";
}
