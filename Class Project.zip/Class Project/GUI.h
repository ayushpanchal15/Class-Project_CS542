#ifndef GUI_H
#define GUI_H

#include "StockMarket.h"
#include "TradingBot.h"
#include <QMainWindow>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QPushButton>

class GUI : public QMainWindow {
    Q_OBJECT
private:
    StockMarket* market;
    TradingBot* bot;
    QTableWidget* stockTable;

public:
    GUI(StockMarket* market, TradingBot* bot);

public slots:
    void updateMarketView();
    void simulateMarket();
    void displayPortfolio();
};

#endif
