#include "StockMarket.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

void StockMarket::addStock(const std::string& name, double price) {
    stocks[name] = price;
}

void StockMarket::updateStockPrice(const std::string& name, double newPrice) {
    stocks[name] = newPrice;
    for (IObserver* observer : observers) {
        observer->update(name, newPrice);
    }
}

void StockMarket::simulatePriceFluctuations() {
    std::srand(std::time(nullptr));
    for (auto& [stock, price] : stocks) {
        double change = (std::rand() % 200 - 100) / 100.0;  // Random change between -1.0 and +1.0
        price += change;
        if (price < 1.0) price = 1.0;  // Ensure price does not drop below 1.0
        updateStockPrice(stock, price);
    }
}

void StockMarket::attach(IObserver* observer) {
    observers.push_back(observer);
}

void StockMarket::detach(IObserver* observer) {
    observers.erase(std::remove(observers.begin(), observers.end(), observer), observers.end());
}

const std::unordered_map<std::string, double>& StockMarket::getStocks() const {
    return stocks;
}
