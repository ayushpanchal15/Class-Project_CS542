#ifndef TRADINGBOT_H
#define TRADINGBOT_H

#include "StockMarket.h"
#include "BankingSystem.h"
#include <unordered_map>
#include <string>

// Strategy Pattern
class InvestmentStrategy {
public:
    virtual std::string chooseStock(const std::unordered_map<std::string, double>& stocks) = 0;
};

class ConservativeStrategy : public InvestmentStrategy {
public:
    std::string chooseStock(const std::unordered_map<std::string, double>& stocks) override;
};

class TradingBot : public IObserver {
private:
    BankingSystem* bank;
    InvestmentStrategy* strategy;
    std::unordered_map<std::string, int> portfolio;

public:
    TradingBot(InvestmentStrategy* strategy);
    void update(const std::string& stock, double price) override;
    void executeTrade(const StockMarket& market);
    void displayPortfolio() const;
    friend class GUI;  // Allows GUI access to portfolio and bank
};

#endif
