#include "StockMarket.h"
#include "TradingBot.h"
#include "GUI.h"
#include "Stock.h"

int main() {
    StockMarket market;
    market.addStock(new Stock("AAPL", 150.0));
    market.addStock(new VolatileStock("GOOG", 2800.0, 0.05));
    market.addStock(new VolatileStock("TSLA", 800.0, 0.1));

    ConservativeStrategy strategy;
    TradingBot bot(&strategy);
    market.attach(&bot);

    GUI gui(&market, &bot);
    gui.run();

    return 0;
}
