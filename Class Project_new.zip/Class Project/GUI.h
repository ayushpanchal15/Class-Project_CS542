#ifndef GUI_H
#define GUI_H

#include "StockMarket.h"
#include "TradingBot.h"
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

class GUI {
private:
    StockMarket* market;
    TradingBot* bot;
    sf::RenderWindow window;

    // GUI Elements
    sf::Font font;
    sf::Text stockText;
    sf::Text portfolioText;
    sf::RectangleShape simulateButton;
    sf::RectangleShape portfolioButton;
    sf::Text simulateButtonText;
    sf::Text portfolioButtonText;

public:
    GUI(StockMarket* market, TradingBot* bot);
    void run();
};

#endif
