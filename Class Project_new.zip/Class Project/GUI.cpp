#include "GUI.h"
#include <sstream>

// Constructor: Initializes the GUI with stock market and trading bot
GUI::GUI(StockMarket* market, TradingBot* bot)
    : market(market), bot(bot), window(sf::VideoMode(800, 600), "Stock Trading Bot") {
    // Load the font
    if (!font.loadFromFile("arial.ttf")) {
        throw std::runtime_error("Failed to load font!");
    }

    // Stock Text
    stockText.setFont(font);
    stockText.setCharacterSize(20);
    stockText.setPosition(20, 20);
    stockText.setFillColor(sf::Color::White);

    // Portfolio Text
    portfolioText.setFont(font);
    portfolioText.setCharacterSize(20);
    portfolioText.setPosition(20, 400);
    portfolioText.setFillColor(sf::Color::White);

    // Simulate Button
    simulateButton.setSize(sf::Vector2f(150, 50));
    simulateButton.setPosition(600, 20);
    simulateButton.setFillColor(sf::Color::Green);

    simulateButtonText.setFont(font);
    simulateButtonText.setString("Simulate");
    simulateButtonText.setCharacterSize(20);
    simulateButtonText.setFillColor(sf::Color::Black);
    simulateButtonText.setPosition(610, 30);

    // Portfolio Button
    portfolioButton.setSize(sf::Vector2f(150, 50));
    portfolioButton.setPosition(600, 100);
    portfolioButton.setFillColor(sf::Color::Blue);

    portfolioButtonText.setFont(font);
    portfolioButtonText.setString("Portfolio");
    portfolioButtonText.setCharacterSize(20);
    portfolioButtonText.setFillColor(sf::Color::Black);
    portfolioButtonText.setPosition(610, 110);
}

// Main loop to run the GUI
void GUI::run() {
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                // Simulate Market Button
                if (simulateButton.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
                    market->simulatePriceFluctuations();
                }

                // Show Portfolio Button
                if (portfolioButton.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
                    // Display portfolio information in the console
                    bot->displayPortfolio();
                }
            }
        }

        // Draw everything
        window.clear();

        // Update stock text
        std::stringstream stockStream;
        for (const auto& [name, stock] : market->getStocks()) {
            stockStream << name << ": $" << stock->getPrice() << "\n";
        }
        stockText.setString(stockStream.str());

        // Draw elements
        window.draw(stockText);
        window.draw(simulateButton);
        window.draw(simulateButtonText);
        window.draw(portfolioButton);
        window.draw(portfolioButtonText);

        window.display();
    }
}
